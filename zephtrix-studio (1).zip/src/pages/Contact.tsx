import { Contact as ContactComponent } from "../components/Contact";

export function Contact() {
  return (
    <main className="pt-24">
      <ContactComponent />
    </main>
  );
}
