import { Portfolio as PortfolioComponent } from "../components/Portfolio";
import { CaseStudy } from "../components/CaseStudy";
import { CTA } from "../components/CTA";

export function Portfolio() {
  return (
    <main className="pt-24">
      <PortfolioComponent />
      <CaseStudy />
      <CTA />
    </main>
  );
}
