import { Services as ServicesComponent } from "../components/Services";
import { Process } from "../components/Process";
import { CTA } from "../components/CTA";

export function Services() {
  return (
    <main className="pt-24">
      <ServicesComponent />
      <Process />
      <CTA />
    </main>
  );
}
