import { About as AboutComponent } from "../components/About";
import { Testimonials } from "../components/Testimonials";
import { CTA } from "../components/CTA";

export function About() {
  return (
    <main className="pt-24">
      <AboutComponent />
      <Testimonials />
      <CTA />
    </main>
  );
}
