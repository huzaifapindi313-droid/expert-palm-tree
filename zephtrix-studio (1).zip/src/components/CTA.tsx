import { motion } from "motion/react";
import { Link } from "react-router-dom";

export function CTA() {
  return (
    <section className="relative py-40 flex flex-col items-center justify-center overflow-hidden border-t border-white/5">
      {/* Immersive Galaxy Background */}
      <div className="absolute inset-0 bg-black z-0" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-4xl h-[400px] bg-gradient-to-r from-red-600/20 via-red-600/20 to-red-600/20 blur-[100px] z-0 rounded-full" />
      
      {/* Particles (simplified CSS) */}
      <div className="absolute inset-0 z-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4IiBoZWlnaHQ9IjgiPgoJPHBhdGggZD0iTTAgMGg4djhIMHoiIGZpbGw9Im5vbmUiLz4KCTxjaXJjbGUgY3g9IjQiIGN5PSI0IiByPSIxIiBmaWxsPSIjZmZmIiBmaWxsLW9wYWNpdHk9IjAuMSIvPgo8L3N2Zz4=')] opacity-50" />

      <motion.div 
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="relative z-10 flex flex-col items-center text-center px-6 max-w-4xl mx-auto"
      >
        <h2 className="text-5xl md:text-7xl font-display font-bold tracking-tight mb-6">
          Your Next Big Idea Deserves More Than an Ordinary Website.
        </h2>
        <p className="text-xl text-white/60 mb-12">
          Let’s transform your vision into a powerful digital experience.
        </p>
        <Link 
          to="/contact"
          className="group relative px-10 py-5 rounded-full bg-white text-black font-semibold text-lg hover:scale-105 transition-transform duration-300"
        >
          <span className="relative z-10">Launch Your Project</span>
          <div className="absolute inset-0 rounded-full bg-gradient-to-r from-red-400 via-red-400 to-red-400 opacity-0 group-hover:opacity-100 blur transition-opacity duration-300 -z-10 scale-110" />
        </Link>
      </motion.div>
    </section>
  );
}
