import { useEffect, useRef } from "react";
import "./CustomCursor.css";

export function CustomCursor() {
  const dotRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    // Detect touch devices or reduced motion preference
    const isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (isTouch || reducedMotion) return;

    let mouseX = window.innerWidth / 2;
    let mouseY = window.innerHeight / 2;
    let dotX = mouseX;
    let dotY = mouseY;
    
    let isVisible = false;
    let isClicked = false;
    
    // Linear interpolation for smooth spring-like easing
    const lerp = (start: number, end: number, factor: number) => {
      return start + (end - start) * factor;
    };

    const evaluateHoverState = (target: HTMLElement | null) => {
        if (!target) return;
        
        const isClickable = target.closest('a, button, [role="button"], input[type="submit"], input[type="button"], [data-cursor], [data-magnetic], img');
        const isInput = target.closest('input:not([type="submit"]):not([type="button"]), textarea, select');
        
        if (dotRef.current) {
            // Hide cursor completely over inputs
            if (isInput) {
               dotRef.current.style.opacity = '0';
            } else {
               dotRef.current.style.opacity = '1';
            }
            
            if (isClicked) {
                dotRef.current.className = 'cursor-dot click';
            } else if (isClickable) {
                dotRef.current.className = 'cursor-dot hover';
            } else {
                dotRef.current.className = 'cursor-dot';
            }
        }
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isVisible) {
        isVisible = true;
        if (dotRef.current) dotRef.current.style.opacity = '1';
      }
      mouseX = e.clientX;
      mouseY = e.clientY;
      
      evaluateHoverState(e.target as HTMLElement);
    };
    
    const onMouseDown = () => {
        isClicked = true;
        evaluateHoverState(document.elementFromPoint(mouseX, mouseY) as HTMLElement);
    };

    const onMouseUp = () => {
        isClicked = false;
        evaluateHoverState(document.elementFromPoint(mouseX, mouseY) as HTMLElement);
    };

    window.addEventListener('mousemove', onMouseMove, { passive: true });
    window.addEventListener('mousedown', onMouseDown, { passive: true });
    window.addEventListener('mouseup', onMouseUp, { passive: true });

    let animationFrameId: number;
    const render = () => {
      // Smooth spring lag
      dotX = lerp(dotX, mouseX, 0.3);
      dotY = lerp(dotY, mouseY, 0.3);
      
      if (dotRef.current) {
        dotRef.current.style.transform = `translate3d(${dotX}px, ${dotY}px, 0) translate(-50%, -50%)`;
      }

      animationFrameId = requestAnimationFrame(render);
    };
    render();

    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div ref={dotRef} className="cursor-dot" style={{ opacity: 0 }}></div>
  );
}
