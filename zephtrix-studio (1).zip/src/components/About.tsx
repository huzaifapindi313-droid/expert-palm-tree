import { motion } from "motion/react";

export function About() {
  return (
    <section id="about" className="py-32 px-6 sm:px-12 max-w-7xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-6xl font-display font-bold tracking-tight mb-8"
          >
            Small Team. <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-red-400">
              Massive Impact.
            </span>
          </motion.h2>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-lg text-white/60 leading-relaxed"
          >
            Zephtrix brings together strategy, design, technology and AI to create digital products that move businesses forward. We work closely with a limited number of clients so every project receives serious attention, ensuring quality that stands far above the ordinary.
          </motion.p>
        </div>

        <div className="grid grid-cols-2 gap-6">
          {[
            { label: "Digital Products Launched", value: "50+" },
            { label: "Global Markets", value: "12" },
            { label: "Client Satisfaction", value: "98%" },
            { label: "Years of Combined Experience", value: "8+" }
          ].map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 + (i * 0.1) }}
              className="p-6 rounded-3xl bg-zinc-950 border border-white/5 flex flex-col justify-center"
            >
              <div className="text-4xl md:text-5xl font-display font-bold text-white mb-2">{stat.value}</div>
              <div className="text-sm text-white/50">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
