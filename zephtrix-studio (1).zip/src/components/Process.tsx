import { useRef } from "react";
import { motion, useScroll, useTransform } from "motion/react";
import { Lightbulb, Target, PenTool, Code, Rocket, TrendingUp } from "lucide-react";
import { cn } from "../lib/utils";

const steps = [
  { id: "01", title: "Discover", description: "Deep dive into your brand, market, and audience to uncover true opportunities.", icon: Lightbulb },
  { id: "02", title: "Strategize", description: "Mapping out a flawless technical and creative roadmap aligned with your goals.", icon: Target },
  { id: "03", title: "Design", description: "Crafting immersive, high-fidelity UI/UX that sets a new industry standard.", icon: PenTool },
  { id: "04", title: "Build", description: "Developing robust, scalable architecture using next-generation frameworks.", icon: Code },
  { id: "05", title: "Launch", description: "Rigorous testing, optimization, and deploying your product to the world.", icon: Rocket },
  { id: "06", title: "Scale", description: "Continuous iteration and performance tuning to ensure sustainable growth.", icon: TrendingUp },
];

export function Process() {
  const containerRef = useRef<HTMLDivElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start center", "end center"]
  });

  return (
    <section id="process" ref={containerRef} className="py-32 px-6 sm:px-12 max-w-7xl mx-auto relative">
      <div className="text-center max-w-2xl mx-auto mb-20">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-4xl md:text-6xl font-display font-bold tracking-tight mb-6"
        >
          From Idea to Impact
        </motion.h2>
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="text-lg text-white/60"
        >
          Our proven framework for delivering digital excellence, carefully orchestrated to turn complex challenges into elegant solutions.
        </motion.p>
      </div>

      <div className="relative">
        {/* Central Line */}
        <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-[1px] bg-white/10 -translate-x-1/2">
          <motion.div 
            className="absolute top-0 w-full bg-gradient-to-b from-red-500 via-red-500 to-red-500 origin-top"
            style={{ 
              scaleY: scrollYProgress,
              height: "100%"
            }}
          />
        </div>

        <div className="space-y-12 md:space-y-24">
          {steps.map((step, index) => {
            const isEven = index % 2 === 0;
            const Icon = step.icon;
            
            return (
              <div key={step.id} className={cn(
                "relative flex items-center md:justify-between",
                isEven ? "md:flex-row-reverse" : "md:flex-row"
              )}>
                
                {/* Connecting Node */}
                <div className="absolute left-4 md:left-1/2 w-8 h-8 -translate-x-1/2 rounded-full bg-black border-2 border-white/20 z-10 flex items-center justify-center">
                  <motion.div 
                    initial={{ scale: 0 }}
                    whileInView={{ scale: 1 }}
                    viewport={{ once: true, margin: "-100px" }}
                    transition={{ type: "spring", stiffness: 300, damping: 20 }}
                    className="w-3 h-3 rounded-full bg-white shadow-[0_0_10px_rgba(255,255,255,0.8)]"
                  />
                </div>

                {/* Content Card */}
                <motion.div 
                  initial={{ opacity: 0, x: isEven ? -50 : 50, y: 20 }}
                  whileInView={{ opacity: 1, x: 0, y: 0 }}
                  viewport={{ once: true, margin: "-100px" }}
                  className={cn(
                    "w-full md:w-[calc(50%-3rem)] pl-16 md:pl-0",
                    isEven ? "md:text-right md:pr-12" : "md:text-left md:pl-12"
                  )}
                >
                  <div className="bg-zinc-950 border border-white/5 p-8 rounded-3xl hover:border-white/20 transition-colors">
                    <div className={cn(
                      "flex items-center gap-4 mb-4",
                      isEven ? "md:flex-row-reverse" : "md:flex-row"
                    )}>
                      <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center text-red-400">
                        <Icon size={20} />
                      </div>
                      <span className="text-4xl font-display font-bold text-white/10">{step.id}</span>
                    </div>
                    <h3 className="text-2xl font-display font-bold mb-3">{step.title}</h3>
                    <p className="text-white/60 leading-relaxed">{step.description}</p>
                  </div>
                </motion.div>
                
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
