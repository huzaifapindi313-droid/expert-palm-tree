import { useRef } from "react";
import { motion, useScroll, useTransform } from "motion/react";
import { Link } from "react-router-dom";

export function Hero() {
  const containerRef = useRef<HTMLDivElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"]
  });
  
  const yText = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const opacityText = useTransform(scrollYProgress, [0, 0.5], [1, 0]);
  const scaleOrb = useTransform(scrollYProgress, [0, 1], [1, 1.5]);

  return (
    <section 
      ref={containerRef}
      className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden pt-32 pb-20"
    >
      {/* Background Particles/Stars */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-1/4 left-1/4 w-1 h-1 bg-white rounded-full blur-[1px] animate-pulse" />
        <div className="absolute top-1/3 right-1/4 w-2 h-2 bg-red-400 rounded-full blur-[2px] animate-pulse delay-75" />
        <div className="absolute bottom-1/4 right-1/3 w-1.5 h-1.5 bg-red-400 rounded-full blur-[1px] animate-pulse delay-150" />
        <div className="absolute top-1/2 left-1/2 w-1 h-1 bg-red-300 rounded-full blur-[1px] animate-pulse delay-300" />
      </div>

      {/* 3D Orb Effect */}
      <motion.div 
        style={{ scale: scaleOrb }}
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] md:w-[600px] md:h-[600px] z-0 pointer-events-none"
      >
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
          className="w-full h-full relative"
        >
          {/* Core */}
          <div className="absolute inset-20 md:inset-40 rounded-full bg-red-600/30 blur-2xl" />
          {/* Gradients */}
          <div className="absolute top-0 right-0 w-1/2 h-1/2 rounded-full bg-red-600/40 blur-[80px]" />
          <div className="absolute bottom-0 left-0 w-1/2 h-1/2 rounded-full bg-red-500/30 blur-[60px]" />
          <div className="absolute top-1/4 left-1/4 w-1/2 h-1/2 rounded-full bg-red-500/20 blur-[100px]" />
          {/* Ring */}
          <div className="absolute inset-10 border border-white/5 rounded-full" />
          <div className="absolute inset-0 border border-red-500/10 rounded-full rotate-45" />
        </motion.div>
      </motion.div>

      {/* Content */}
      <motion.div 
        style={{ y: yText, opacity: opacityText }}
        className="relative z-10 flex flex-col items-center text-center px-4 max-w-5xl mx-auto mt-20"
      >
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-md mb-8"
        >
          <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          <span className="text-sm font-medium tracking-wide text-white/80 uppercase">
            Digital Agency of the Future
          </span>
        </motion.div>

        <motion.h1 
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.4 }}
          className="text-5xl md:text-7xl lg:text-8xl font-display font-bold tracking-tight leading-[1.1] mb-6"
        >
          We Build Digital Experiences That <br className="hidden md:block" />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-400 via-red-400 to-red-400">
            Explode With Possibility.
          </span>
        </motion.h1>

        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.6 }}
          className="text-lg md:text-xl text-white/60 max-w-2xl mb-12 font-light"
        >
          Zephtrix Studio creates premium websites, AI applications and digital products for ambitious brands ready to grow beyond ordinary.
        </motion.p>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.8 }}
          className="flex flex-col sm:flex-row items-center gap-6"
        >
          <Link
            to="/contact"
            data-cta="true"
            data-magnetic="true"
            className="px-8 py-4 rounded-full bg-white text-black font-semibold tracking-wide hover:scale-105 transition-transform duration-300"
          >
            Start Your Project
          </Link>
          <Link
            to="/portfolio"
            data-magnetic="true"
            className="px-8 py-4 rounded-full border border-white/20 text-white font-semibold tracking-wide hover:bg-white/5 transition-colors duration-300"
          >
            Explore Our Work
          </Link>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.2 }}
          className="mt-16 text-sm text-white/40 tracking-wider"
        >
          Trusted by ambitious founders, startups and growing brands.
        </motion.div>
      </motion.div>
    </section>
  );
}
