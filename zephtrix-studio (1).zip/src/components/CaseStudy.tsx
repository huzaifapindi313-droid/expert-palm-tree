import { useEffect, useState, useRef } from "react";
import { motion, useInView } from "motion/react";
import { ArrowUpRight } from "lucide-react";

function Counter({ from, to, duration = 2, suffix = "", prefix = "" }: { from: number, to: number, duration?: number, suffix?: string, prefix?: string }) {
  const [count, setCount] = useState(from);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  useEffect(() => {
    if (isInView) {
      let startTime: number;
      const step = (timestamp: number) => {
        if (!startTime) startTime = timestamp;
        const progress = Math.min((timestamp - startTime) / (duration * 1000), 1);
        
        // Easing function (easeOutExpo)
        const easeProgress = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
        setCount(Math.floor(easeProgress * (to - from) + from));
        
        if (progress < 1) {
          window.requestAnimationFrame(step);
        }
      };
      window.requestAnimationFrame(step);
    }
  }, [isInView, from, to, duration]);

  // Handle floats specifically for the 3.2x or 2.1s cases if needed, but since it's just a visual counter,
  // we'll format based on what's passed or just use hardcoded strings for decimal parts if easier.
  // Actually, standard math floor is fine for whole numbers. Let's assume 'to' is an integer, or pass formatted string.
  
  return <span ref={ref}>{prefix}{count}{suffix}</span>;
}

export function CaseStudy() {
  return (
    <section className="py-32 px-6 sm:px-12 max-w-7xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        {/* Left: Content */}
        <div className="order-2 lg:order-1">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/10 text-red-400 text-sm font-semibold mb-6 uppercase tracking-wider"
          >
            Featured Case Study
          </motion.div>
          
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-display font-bold tracking-tight mb-6 leading-tight text-white"
          >
            Transforming Legacy Systems into Modern Masterpieces.
          </motion.h2>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-white/60 text-lg leading-relaxed mb-10"
          >
            A leading enterprise software company approached us with a challenge: their complex legacy system was losing users to faster, modern competitors. We completely reimagined their UI/UX and rebuilt the platform from the ground up using React and a modern API architecture.
          </motion.p>

          <div className="grid grid-cols-2 gap-8 mb-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
            >
              <h4 className="text-sm font-semibold text-white/40 uppercase tracking-wide mb-2">Services</h4>
              <ul className="text-white/80 space-y-2">
                <li>UI/UX Design</li>
                <li>Frontend Architecture</li>
                <li>Performance Audit</li>
              </ul>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4 }}
            >
              <h4 className="text-sm font-semibold text-white/40 uppercase tracking-wide mb-2">Outcome</h4>
              <p className="text-white/80">Delivered a lightning-fast dashboard that recovered lost market share within 3 months.</p>
            </motion.div>
          </div>
          
          <motion.a
            href="#"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5 }}
            className="inline-flex items-center gap-2 text-white border-b border-white pb-1 hover:text-red-400 hover:border-red-400 transition-colors"
          >
            Read the full story <ArrowUpRight size={18} />
          </motion.a>
        </div>

        {/* Right: Stats and Visual */}
        <div className="order-1 lg:order-2">
          <div className="relative rounded-3xl bg-zinc-950 border border-white/5 p-8 overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-red-500/20 rounded-full blur-[80px]" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-red-500/20 rounded-full blur-[80px]" />
            
            <div className="relative z-10 grid grid-cols-1 sm:grid-cols-2 gap-6">
              {[
                { label: "Increase in Conversions", prefix: "", to: 320, suffix: "%" }, // Representing 3.2x as 320%
                { label: "Engagement Improvement", prefix: "", to: 48, suffix: "%" },
                { label: "Reduction in Drop-off", prefix: "", to: 60, suffix: "%" },
                { label: "Faster Load Times", prefix: "", to: 80, suffix: "%" }
              ].map((stat, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.2 + (i * 0.1) }}
                  className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-sm"
                >
                  <div className="text-4xl md:text-5xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-red-400 mb-2">
                    <Counter from={0} to={stat.to} suffix={stat.suffix} prefix={stat.prefix} />
                  </div>
                  <div className="text-sm font-medium tracking-wide text-white/60">
                    {stat.label}
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Dashboard Mockup abstract UI */}
            <motion.div 
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.6 }}
              className="mt-8 bg-white/5 border border-white/10 rounded-xl p-4 flex gap-4 backdrop-blur-md"
            >
              <div className="w-12 h-12 rounded-lg bg-red-500/20" />
              <div className="flex-1 space-y-3 py-1">
                <div className="h-2 bg-white/20 rounded-full w-3/4" />
                <div className="h-2 bg-white/10 rounded-full w-1/2" />
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
