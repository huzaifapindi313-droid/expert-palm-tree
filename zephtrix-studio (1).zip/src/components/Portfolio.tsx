import { useRef } from "react";
import { motion, useScroll, useTransform } from "motion/react";

const projects = [
  {
    title: "Aura AI",
    category: "AI Application",
    result: "40% Increase in Workflow Speed",
    image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80&w=1600",
  },
  {
    title: "NexPay",
    category: "Fintech Dashboard",
    result: "$2M Processed in First Month",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=1600",
  },
  {
    title: "Lumina",
    category: "Luxury Brand Website",
    result: "Award-winning Digital Experience",
    image: "https://images.unsplash.com/photo-1600607686527-6fb886090705?auto=format&fit=crop&q=80&w=1600",
  },
  {
    title: "Sync",
    category: "SaaS Platform",
    result: "10k+ Active Daily Users",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=1600",
  },
  {
    title: "Velocity",
    category: "Mobile App",
    result: "4.9/5 Average App Store Rating",
    image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?auto=format&fit=crop&q=80&w=1600",
  },
  {
    title: "Verve",
    category: "E-commerce Experience",
    result: "3.2x Conversion Rate Growth",
    image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=1600",
  }
];

export function Portfolio() {
  const targetRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: targetRef,
  });

  const x = useTransform(scrollYProgress, [0, 1], ["0%", "-75%"]);

  return (
    <section id="work" ref={targetRef} className="relative h-[300vh] bg-black">
      <div className="sticky top-0 h-screen flex flex-col justify-center overflow-hidden">
        <div className="px-6 sm:px-12 max-w-7xl mx-auto w-full mb-12">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-display font-bold tracking-tight"
          >
            Selected Missions
          </motion.h2>
        </div>

        <motion.div style={{ x }} className="flex gap-8 px-6 sm:px-12 w-[400vw] md:w-[300vw] lg:w-[200vw]">
          {projects.map((project, index) => (
            <div 
              key={index}
              data-cursor="View"
              className="group relative w-[85vw] md:w-[60vw] lg:w-[40vw] h-[60vh] md:h-[70vh] rounded-3xl overflow-hidden shrink-0 cursor-none"
            >
              {/* Project Image */}
              <div className="absolute inset-0 bg-gray-900">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-full object-cover opacity-60 group-hover:opacity-80 group-hover:scale-105 transition-all duration-700 ease-[cubic-bezier(0.16,1,0.3,1)]"
                />
              </div>
              
              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

              {/* Project Details */}
              <div className="absolute inset-0 p-8 flex flex-col justify-end">
                <div className="translate-y-8 group-hover:translate-y-0 transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]">
                  <p className="text-red-400 font-medium tracking-wide text-sm uppercase mb-3">
                    {project.category}
                  </p>
                  <h3 className="text-4xl md:text-5xl font-display font-bold text-white mb-2">
                    {project.title}
                  </h3>
                  <p className="text-white/70 text-lg opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100">
                    {project.result}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
