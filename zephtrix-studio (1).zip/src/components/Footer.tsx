import { Link } from "react-router-dom";

export function Footer() {
  return (
    <footer className="bg-black pt-20 pb-10 px-6 sm:px-12 border-t border-white/5">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="lg:col-span-2">
            <div className="text-2xl font-display font-bold tracking-tight mb-4">
              ZEPHTRIX<span className="text-red-500">.</span>
            </div>
            <p className="text-white/60 max-w-sm mb-6">
              A high-end digital agency designing the future of web and mobile experiences.
            </p>
            <h4 className="font-display font-bold text-white text-lg tracking-wider">
              Designed to go beyond ordinary.
            </h4>
          </div>

          <div>
            <h4 className="font-semibold text-white/40 uppercase tracking-wide mb-4 text-sm">Navigation</h4>
            <ul className="space-y-3">
              <li><Link to="/" className="text-white/70 hover:text-white transition-colors">Home</Link></li>
              <li><Link to="/services" className="text-white/70 hover:text-white transition-colors">Our Services</Link></li>
              <li><Link to="/portfolio" className="text-white/70 hover:text-white transition-colors">Portfolio</Link></li>
              <li><Link to="/about" className="text-white/70 hover:text-white transition-colors">About Us</Link></li>
              <li><Link to="/contact" className="text-white/70 hover:text-white transition-colors">Contact Us</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-white/40 uppercase tracking-wide mb-4 text-sm">Socials</h4>
            <ul className="space-y-3">
              <li><a href="#" className="text-white/70 hover:text-white transition-colors">Twitter (X)</a></li>
              <li><a href="#" className="text-white/70 hover:text-white transition-colors">LinkedIn</a></li>
              <li><a href="#" className="text-white/70 hover:text-white transition-colors">Instagram</a></li>
              <li><a href="#" className="text-white/70 hover:text-white transition-colors">Dribbble</a></li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col md:flex-row items-center justify-between pt-8 border-t border-white/10 text-sm text-white/40 gap-4">
          <p>© {new Date().getFullYear()} Zephtrix Studio. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
