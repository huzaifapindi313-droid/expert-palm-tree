import { useState, FormEvent } from "react";
import { motion } from "motion/react";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { cn } from "../lib/utils";

export function Contact() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 1500);
  };

  return (
    <section id="contact" className="py-32 px-6 sm:px-12 max-w-7xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
        <div>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-6xl font-display font-bold tracking-tight mb-6"
          >
            Ready to <br />
            go beyond?
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-lg text-white/60 max-w-md mb-12"
          >
            Tell us about your project. Our team will review your requirements and get back to you within 24 hours to schedule a discovery call.
          </motion.p>
          
          <div className="space-y-6">
            <div>
              <h4 className="text-sm font-semibold text-white/40 uppercase tracking-wide mb-2">Email Us</h4>
              <a href="mailto:hello@zephtrix.com" className="text-xl text-white hover:text-red-400 transition-colors">hello@zephtrix.com</a>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-white/40 uppercase tracking-wide mb-2">Location</h4>
              <p className="text-xl text-white">Global (Remote First)</p>
            </div>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          {isSuccess ? (
            <div className="h-full min-h-[500px] flex flex-col items-center justify-center text-center p-8 bg-zinc-950 border border-white/5 rounded-3xl">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring" }}
              >
                <CheckCircle2 size={64} className="text-red-500 mb-6" />
              </motion.div>
              <h3 className="text-3xl font-display font-bold mb-4">Request Received</h3>
              <p className="text-white/60 mb-8">Thank you for reaching out. We will review your details and be in touch shortly.</p>
              <button 
                onClick={() => setIsSuccess(false)}
                className="px-6 py-3 rounded-full border border-white/20 text-sm hover:bg-white/5 transition-colors"
              >
                Submit another project
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="p-8 md:p-10 bg-zinc-950 border border-white/5 rounded-3xl space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm text-white/60">Name</label>
                  <input required type="text" className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-red-500 transition-colors" placeholder="John Doe" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm text-white/60">Company</label>
                  <input type="text" className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-red-500 transition-colors" placeholder="Company Inc." />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm text-white/60">Email</label>
                  <input required type="email" className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-red-500 transition-colors" placeholder="john@example.com" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm text-white/60">Project Type</label>
                  <select required defaultValue="" className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-red-500 transition-colors appearance-none">
                    <option value="" disabled>Select an option</option>
                    <option value="website">Premium Website</option>
                    <option value="app">Mobile App</option>
                    <option value="saas">SaaS Platform</option>
                    <option value="ai">AI Application</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm text-white/60">Estimated Budget (USD)</label>
                <select required defaultValue="" className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-red-500 transition-colors appearance-none">
                  <option value="" disabled>Select a range</option>
                  <option value="tier1">$2,000 – $5,000</option>
                  <option value="tier2">$5,000 – $10,000</option>
                  <option value="tier3">$10,000 – $25,000</option>
                  <option value="tier4">$25,000+</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm text-white/60">Project Details</label>
                <textarea required rows={4} className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-red-500 transition-colors resize-none" placeholder="Tell us about your goals and vision..." />
              </div>

              <button 
                type="submit" 
                disabled={isSubmitting}
                className={cn(
                  "w-full py-4 rounded-xl font-semibold text-black flex items-center justify-center gap-2 transition-all",
                  isSubmitting ? "bg-white/50 cursor-not-allowed" : "bg-white hover:scale-[1.02]"
                )}
              >
                {isSubmitting ? "Sending..." : (
                  <>Submit Request <ArrowRight size={18} /></>
                )}
              </button>
            </form>
          )}
        </motion.div>
      </div>
    </section>
  );
}
