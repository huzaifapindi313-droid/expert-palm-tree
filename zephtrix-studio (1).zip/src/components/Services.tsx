import { motion } from "motion/react";
import { 
  Monitor, 
  Cpu, 
  Smartphone, 
  Cloud, 
  Layers, 
  ShoppingCart,
  Server,
  PenTool,
  Film,
  PlaySquare,
  Megaphone,
  Box,
  Hexagon,
  LayoutTemplate,
  Shield,
  Terminal,
  Rocket,
  Wand2,
  Clapperboard,
  PlayCircle,
  Code,
  LayoutDashboard
} from "lucide-react";
import { cn } from "../lib/utils";

const services = [
  {
    title: "App Development",
    description: "Native and cross-platform applications for Android, iOS, and Desktop built for performance.",
    icon: Smartphone,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "Website Development",
    description: "Bespoke, responsive, and high-performance websites tailored to your brand's unique needs.",
    icon: Monitor,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "Shopify Website Designing",
    description: "Premium e-commerce experiences optimized for conversions and seamless user journeys.",
    icon: ShoppingCart,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "AI Automation",
    description: "Intelligent workflows and automations leveraging advanced AI to scale your operations.",
    icon: Cpu,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "SaaS Product Development",
    description: "Scalable, secure, and intuitive platforms designed for high-growth software companies.",
    icon: Cloud,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "Website Hosting",
    description: "Lightning-fast, secure, and reliable hosting solutions ensuring maximum uptime.",
    icon: Server,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "Graphic Design",
    description: "Visually striking branding and graphic assets that communicate your brand's core message.",
    icon: PenTool,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "Video Editing",
    description: "Professional video editing that crafts compelling narratives and engages your audience.",
    icon: Film,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "Motion Graphics",
    description: "Dynamic and fluid motion graphics to bring your ideas and brand identity to life.",
    icon: PlaySquare,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "UI/UX Design",
    description: "Comprehensive design languages that ensure consistency and accessibility across all touchpoints.",
    icon: Layers,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "Social Media Marketing",
    description: "Strategic marketing campaigns to boost brand awareness and drive meaningful engagement.",
    icon: Megaphone,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "3D Designing",
    description: "Immersive 3D modeling and rendering for products, environments, and virtual experiences.",
    icon: Box,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "3D Motion Graphics",
    description: "High-end 3D animations and simulations delivering striking visual storytelling.",
    icon: Hexagon,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "WordPress Development",
    description: "Custom, fully manageable, and responsive WordPress websites tailored to your exact needs.",
    icon: LayoutTemplate,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "Cyber Security",
    description: "Robust security protocols and audits to protect your digital infrastructure and assets.",
    icon: Shield,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "Ethical Hacking",
    description: "Proactive vulnerability assessments and penetration testing to fortify your systems.",
    icon: Terminal,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "Business Startup",
    description: "Comprehensive digital strategies and technical foundations to launch and scale your startup.",
    icon: Rocket,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "VFX",
    description: "Stunning visual effects seamlessly integrated to elevate your video production quality.",
    icon: Wand2,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "CGI",
    description: "Computer-generated imagery bringing impossible concepts to photorealistic reality.",
    icon: Clapperboard,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "Animations",
    description: "Engaging 2D and 3D character and environmental animations for games and media.",
    icon: PlayCircle,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "Custom Software",
    description: "End-to-end custom software solutions engineered to solve complex business challenges.",
    icon: Code,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  },
  {
    title: "Custom Dashboard",
    description: "Intuitive data visualization dashboards integrating multiple data sources seamlessly.",
    icon: LayoutDashboard,
    color: "from-red-500/20 to-red-500/0",
    border: "group-hover:border-red-500/50"
  }
];

export function Services() {
  return (
    <section id="services" className="py-32 px-6 sm:px-12 max-w-7xl mx-auto relative z-10">
      <div className="mb-20">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-4xl md:text-6xl font-display font-bold tracking-tight mb-6"
        >
          What We Create
        </motion.h2>
        <motion.div 
          initial={{ opacity: 0, w: 0 }}
          whileInView={{ opacity: 1, w: "100px" }}
          viewport={{ once: true }}
          className="h-1 bg-gradient-to-r from-red-500 to-red-500 rounded-full w-24"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {services.map((service, index) => {
          const Icon = service.icon;
          return (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className={cn(
                "group relative p-8 rounded-3xl bg-zinc-950 border border-white/5 overflow-hidden transition-all duration-500",
                service.border
              )}
            >
              {/* Hover Background Glow */}
              <div 
                className={cn(
                  "absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-gradient-to-br",
                  service.color
                )}
              />
              
              <div className="relative z-10 flex flex-col h-full">
                <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-500">
                  <Icon className="w-7 h-7 text-white/70 group-hover:text-white transition-colors" />
                </div>
                
                <h3 className="text-2xl font-display font-semibold mb-4 text-white group-hover:-translate-y-1 transition-transform duration-300">
                  {service.title}
                </h3>
                
                <p className="text-white/60 leading-relaxed group-hover:text-white/80 transition-colors">
                  {service.description}
                </p>

                <div className="mt-8 overflow-hidden">
                  <div className="flex items-center gap-2 text-sm font-medium tracking-wide text-white/40 group-hover:text-white/90 translate-y-8 group-hover:translate-y-0 transition-all duration-300">
                    Explore Capability <span className="text-xl">→</span>
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
