import { useRef, useState, useEffect } from "react";
import { motion } from "motion/react";

const testimonials = [
  {
    name: "Elena Rodriguez",
    role: "Founder",
    company: "Lumina",
    quote: "Zephtrix completely transformed our brand's digital presence. The attention to detail and 3D interactions elevate our site beyond anything in our industry.",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=256",
    category: "Luxury Brand Website"
  },
  {
    name: "Marcus Chen",
    role: "CEO",
    company: "Sync Platform",
    quote: "Their process is incredibly smooth, and the AI integration they built for us helped scale our operations by 300% in six months.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=256",
    category: "AI Application"
  },
  {
    name: "Sarah Jenkins",
    role: "Product Lead",
    company: "NexPay",
    quote: "Finding an agency that truly understands premium SaaS architecture is rare. Zephtrix delivered a fast, beautiful dashboard that our users love.",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=256",
    category: "Fintech Dashboard"
  },
  {
    name: "David O'Connor",
    role: "Marketing Director",
    company: "Verve",
    quote: "The conversion rates on our new e-commerce experience speak for themselves. Zephtrix blends stunning visuals with highly functional UX.",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=256",
    category: "E-commerce Experience"
  }
];

export function Testimonials() {
  const [width, setWidth] = useState(0);
  const carousel = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (carousel.current) {
      setWidth(carousel.current.scrollWidth - carousel.current.offsetWidth);
    }
  }, []);

  return (
    <section className="py-32 overflow-hidden bg-zinc-950 border-y border-white/5 relative">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0IiBoZWlnaHQ9IjQiPgoJPHJlY3Qgd2lkdGg9IjQiIGhlaWdodD0iNCIgZmlsbD0iI2ZmZiIgZmlsbC1vcGFjaXR5PSIwLjAyIi8+Cjwvc3ZnPg==')] opacity-30 pointer-events-none" />
      
      <div className="px-6 sm:px-12 max-w-7xl mx-auto mb-16">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-4xl md:text-5xl font-display font-bold tracking-tight text-white"
        >
          What Our Clients Say
        </motion.h2>
      </div>

      <motion.div 
        ref={carousel} 
        className="cursor-grab active:cursor-grabbing overflow-hidden pl-6 sm:pl-12"
        whileTap={{ cursor: "grabbing" }}
        data-cursor="Drag"
      >
        <motion.div 
          drag="x" 
          dragConstraints={{ right: 0, left: -width - 48 }}
          className="flex gap-6 w-max"
        >
          {testimonials.map((testimonial, idx) => (
            <div 
              key={idx} 
              className="min-w-[320px] md:min-w-[480px] p-8 md:p-10 rounded-3xl bg-black border border-white/5 shrink-0 select-none"
            >
              <div className="mb-8">
                <span className="text-xs font-semibold tracking-wider text-red-400 uppercase bg-red-500/10 px-3 py-1 rounded-full">
                  {testimonial.category}
                </span>
              </div>
              
              <p className="text-lg md:text-xl text-white/80 leading-relaxed mb-10 italic">
                "{testimonial.quote}"
              </p>
              
              <div className="flex items-center gap-4">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover border border-white/10"
                />
                <div>
                  <h4 className="text-white font-medium">{testimonial.name}</h4>
                  <p className="text-sm text-white/50">{testimonial.role}, {testimonial.company}</p>
                </div>
              </div>
            </div>
          ))}
        </motion.div>
      </motion.div>
    </section>
  );
}
